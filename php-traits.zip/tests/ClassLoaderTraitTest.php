<?php
/**
 *
 * @filesource   ClassLoaderTraitTest.php
 * @created      23.03.2016
 * @package      Traits
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace chillerlan\TraitTest;

use chillerlan\Traits\ClassLoader;
use PHPUnit\Framework\TestCase;

class ClassLoaderTraitTest extends TestCase{
	use ClassLoader;

	public function testLoadClass(){
		$actual = $this->loadClass(tClass::class, tInterface::class);
		$this->assertInstanceOf(tAbstract::class, $actual);
		$this->assertEquals('foo', $actual->test('foo'));
		$this->assertEquals('bar', $actual->testTrait('bar'));
	}

	/**
	 * @expectedException \chillerlan\Traits\TraitException
	 * @expectedExceptionMessage \whatever\foo does not exist
	 */
	public function testLoadClassExceptionA(){
		$this->loadClass('\\whatever\\foo', tInterface::class);
	}

	/**
	 * @expectedException \chillerlan\Traits\TraitException
	 * @expectedExceptionMessage \whatever\bar does not exist
	 */
	public function testLoadClassExceptionB(){
		$this->loadClass(tClass::class, '\\whatever\\bar');
	}

	/**
	 * @expectedException \chillerlan\Traits\TraitException
	 * @expectedExceptionMessage chillerlan\TraitTest\tClass does not inherit stdClass
	 */
	public function testLoadClassExceptionC(){
		$this->loadClass(tClass::class, \stdClass::class);
	}
}
