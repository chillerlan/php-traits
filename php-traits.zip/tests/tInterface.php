<?php
/**
 * Interface tInterface
 *
 * @filesource   tInterface.php
 * @created      13.11.2017
 * @package      chillerlan\TraitTest
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace chillerlan\TraitTest;

interface tInterface{
	public function test(string $test):string;
	public function testTrait(string $test):string;
}
