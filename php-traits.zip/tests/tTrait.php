<?php
/**
 * Trait tTrait
 *
 * @filesource   tTrait.php
 * @created      13.11.2017
 * @package      chillerlan\TraitTest
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace chillerlan\TraitTest;

trait tTrait{

	public function testTrait(string $test):string{
		return $test;
	}

}
