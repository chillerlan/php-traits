<?php
/**
 * Class tAbstract
 *
 * @filesource   tAbstract.php
 * @created      13.11.2017
 * @package      chillerlan\TraitTest
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2015 Smiley
 * @license      MIT
 */

namespace chillerlan\TraitTest;

class tAbstract implements tInterface{
	use tTrait;

	public function test(string $test):string{
		return $test;
	}
}
