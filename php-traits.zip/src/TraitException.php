<?php
/**
 * Class TraitException
 *
 * @filesource   TraitException.php
 * @created      13.11.2017
 * @package      chillerlan\Traits
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2017 Smiley
 * @license      MIT
 */

namespace chillerlan\Traits;

/**
 */
class TraitException extends \Exception{}
