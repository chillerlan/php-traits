<?php
/**
 * Trait ClassLoader
 *
 * @filesource   ClassLoader.php
 * @created      13.11.2017
 * @package      chillerlan\Traits
 * @author       Smiley <smiley@chillerlan.net>
 * @copyright    2017 Smiley
 * @license      MIT
 */

namespace chillerlan\Traits;

use Exception;
use ReflectionClass;

trait ClassLoader{

	/**
	 * A simple class loader
	 *
	 * @param string $class  class FQCN
	 * @param string $type   parent/interface FQCN
	 *
	 * @param mixed $params [optional] the following arguments are optional and
	 *                      will be passed to the class constructor if present.
	 *
	 * @return object of type $type
	 * @throws \Exception
	 */
	public function loadClass(string $class, string $type, ...$params){

		/*

		 $traitsNames = [];
		$recursiveClasses = function ($class) use(&$recursiveClasses, &$traitsNames) {
		    if ($class->getParentClass() != false) {
		        $recursiveClasses($class->getParentClass());
		    }
		    else {
		        $traitsNames = array_merge($traitsNames, $class->getTraitNames());
		    }
		};
		$recursiveClasses($controllerClass);
		 */
		try{
			$reflectionClass = new ReflectionClass($class);
			$reflectionType  = new ReflectionClass($type);

			if($reflectionType->isTrait()){
				trigger_error($class.' cannot be an instance of trait '.$type);
			}

			if($reflectionClass->isAbstract()){
				trigger_error('cannot instance abstract class '.$class);
			}

			if($reflectionClass->isTrait()){
				trigger_error('cannot instance trait '.$class);
			}

			if($reflectionType->isInterface() && !$reflectionClass->implementsInterface($type)){
				trigger_error($class.' does not implement '.$type);
			}
			elseif(!$reflectionClass->isSubclassOf($type)) {
				trigger_error($class.' does not inherit '.$type);
			}

			$object = $reflectionClass->newInstanceArgs($params);

			return $object;
		}
		catch(Exception $e){
			throw new TraitException($e->getMessage());
		}

	}

}
